<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CsvImport;
use Faker\Generator as Faker;

$factory->define(CsvImport::class, function (Faker $faker) {
    return [
        //
    ];
});
