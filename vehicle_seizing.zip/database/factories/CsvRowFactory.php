<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CsvRow;
use Faker\Generator as Faker;

$factory->define(CsvRow::class, function (Faker $faker) {
    return [
        //
    ];
});
