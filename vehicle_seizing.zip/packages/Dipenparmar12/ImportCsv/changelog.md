# Changelog

All notable changes to `ImportCsv` will be documented in this file.

## Version 1.0

### Added
- Everything
