<?php

namespace Dipenparmar12\ImportCsv\Exceptions;

use Exception;

class MySqlException extends Exception
{
    /**
     * {@inheritdoc}
     */
    // protected $message = "Enable load data from local file, by sql query 'set global local_infile=true' ";
}
