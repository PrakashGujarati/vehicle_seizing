# ImportCsv

[![Latest Version on Packagist][ico-version]][link-packagist]
[![Total Downloads][ico-downloads]][link-downloads]
[![Build Status][ico-travis]][link-travis]

Import millions of record in few seconds by using `mysqlimport` utility

## Installation

Via Composer

``` bash
$ composer require dipenparmar12/importcsv
```

## Usage

## Change log

Please see the [changelog](changelog.md) for more information on what has changed recently.

## Testing

``` bash
$ composer test
```

## Contributing

Please see [contributing.md](contributing.md) for details and a todolist.

## Security

If you discover any security related issues, please email author email instead of using the issue tracker.

## Credits

- [author name][link-author]
- [All Contributors][link-contributors]

## License

license. Please see the [license file](license.md) for more information.

[ico-version]: https://img.shields.io/packagist/v/dipenparmar12/importcsv.svg?style=flat-square
[ico-downloads]: https://img.shields.io/packagist/dt/dipenparmar12/importcsv.svg?style=flat-square
[ico-travis]: https://img.shields.io/travis/dipenparmar12/importcsv/master.svg?style=flat-square
[ico-styleci]: https://styleci.io/repos/12345678/shield

[link-packagist]: https://packagist.org/packages/dipenparmar12/importcsv
[link-downloads]: https://packagist.org/packages/dipenparmar12/importcsv
[link-travis]: https://travis-ci.org/dipenparmar12/importcsv
[link-styleci]: https://styleci.io/repos/12345678
[link-author]: https://github.com/dipenparmar12
[link-contributors]: ../../contributors
