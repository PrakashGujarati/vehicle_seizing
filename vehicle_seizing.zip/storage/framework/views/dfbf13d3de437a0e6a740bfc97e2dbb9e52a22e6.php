<div class="flash-message">
  <?php $__currentLoopData = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'light']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has($msg)): ?>
      <div class="alert alert-<?php echo e($msg); ?>" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <div><?php echo e(Session::get($msg)); ?></div>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row">
  <div class="col-12">
<?php if($errors->any()): ?>
  <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
  </div>
</div><?php /**PATH C:\xampp\htdocs\vehicle_seizing\resources\views/layouts/flash_message.blade.php ENDPATH**/ ?>