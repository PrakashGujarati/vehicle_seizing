@extends('layouts.main')
@section('title', __('Dashboard'))
@section('content')

  
@endsection
@section('onPageJs')
 

@endsection