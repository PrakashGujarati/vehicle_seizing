<?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e(isset($user->name) ? $user->name:''); ?></td>
  <td><?php echo e(isset($user->email) ? $user->email:''); ?></td>
  <td><?php echo e(isset($user->contact) ? $user->contact:''); ?></td>
  <td><?php echo e(isset($user->role) ? $user->role:''); ?></td>
  <td><?php echo e(isset($user->status) ? $user->status:''); ?></td>
  <td>

      <a title="Edit" href="<?php echo e(route('user.edit',$user->id)); ?>">
        <i class="fas fa-edit"></i>
      </a>

    
  </td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/user/dynamic_user_table.blade.php ENDPATH**/ ?>