<?php $__currentLoopData = $Officedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Officedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
           <td><?php echo e(isset($Officedata->headOfficesname->name) ? $Officedata->headOfficesname->name:''); ?></td>
           <td><?php echo e(isset($Officedata->name) ? $Officedata->name:''); ?></td>
           <td><?php echo e(isset($Officedata->contact_person) ? $Officedata->contact_person:''); ?></td>
           <td><?php echo e(isset($Officedata->contact) ? $Officedata->contact:''); ?></td>
           <td><?php echo e(isset($Officedata->address1) ? $Officedata->address1:''); ?></td>
           <td><?php echo e(isset($Officedata->city) ? $Officedata->city:''); ?></td>
           <td><?php echo e(isset($Officedata->branch_code) ? $Officedata->branch_code:''); ?></td>
           <td><?php echo e(isset($Officedata->branch) ? $Officedata->branch:''); ?></td>
           <td>
            <div class="d-flex">
            <a title="Edit" href="<?php echo e(route('office.edit',$Officedata->id)); ?>">
                <i class="fas fa-edit"></i>
              </a>
              <form action="<?php echo e(URL::route('office.destroy',$Officedata->id)); ?>" method="POST">
                  <input type="hidden" name="_method" value="DELETE">
                  <?php echo csrf_field(); ?>
                  <button style="background-color: Transparent;
                  background-repeat:no-repeat;
                  border: none;
                  cursor:pointer;
                  overflow: hidden;
                  outline:none;" class="text-danger mr-2"> <i class="fas fa-trash"></i></button>
              </form>
              </div>
           </td>

         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/office/dynamic_office_table.blade.php ENDPATH**/ ?>