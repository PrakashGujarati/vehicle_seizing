
<?php $__env->startSection('title', __('User List')); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
   <div class="row">
      <div class="col-md-6">
         <h5>Subscription List</h5>
      </div>
      <div class="col-md-6">
         <div class="float-md-right">
           <a class="btn btn-primary btn-sm" href="<?php echo e(route('subscription.create')); ?>">New Subscription Add</a>
         </div>
      </div>
   </div>
    <hr>
  
  <div class="row">
      <div class="col-md-12">
         <div class="float-md-right">
          <div class="input-group ">
               <input type="text" class="searchString form-control" name="s" id="search"  placeholder="Search..." id="myInput"  autocompelete="false"> 
            </div><br>
         </div>
      </div>
   </div>
   
 
   <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="data">
      <thead>
         <tr>
              <th>User Name</th>
              <th>Days</th>
              <th>Amount</th>
              <th>Payment Status</th>
              <th>Payment Mode</th>
              <th>Notes</th>
             
         </tr>
         <tbody class="subscription_table_dynamic">
            <?php echo $__env->make('subscription.dynamic_subscription_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tbody>
      </thead>
   </table>
</div>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('onPageJs'); ?>
 
<script type="text/javascript">
  
$('#search').on('keyup',function(){
    var myInput=$(this).val();
    $.ajax({
      type : 'get',
      url : '<?php echo e(route('subscription.search')); ?>',
      data: {
              "s":myInput,
            },
      success:function(data){
         $('.subscription_table_dynamic').html(data.data);
              tableScript();
      }
    });
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/subscription/table.blade.php ENDPATH**/ ?>