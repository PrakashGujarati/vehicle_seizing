
<?php $__env->startSection('title', __('HeadOffice Add')); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="card">
		<div class="card-header">HeadOffice</div>
		<div class="card-body">
			<form method="post" action="<?php echo e(route('headoffice.store')); ?>">
    		<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="name">Name</label>*				
						<input placeholder="Enter head office name" maxlength="100" class="form-control" name="name" id="name"
						 type="text">
						 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						<div class="err"></div>
					</div>

					<div class="form-group">
						<label for="vendor_code">Vendor Code</label> *				
						<input class="form-control" placeholder="Enter vendor code" maxlength="30" name="vendor_code" id="vendor_code" type="text">
						<?php $__errorArgs = ['vendor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										<div class="err"></div>
					</div>
				</div>

				<div class="col-md-4">
					<div class="form-group">
						<label for="address1">Address 1</label>				
						<textarea class="form-control" placeholder="Enter address 1" maxlength="200" rows="4" name="address1" id="address1"></textarea>
								
						<?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		<div class="err"></div>
					</div>
				</div>

				<div class="col-md-4">
					<div class="form-group">
						<label for="address2">Address 2</label>				
						<textarea class="form-control" placeholder="Enter address 2" maxlength="200" rows="4" name="address2" id="address2"></textarea>
						<?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										<div class="err"></div>
					</div>
				</div>

				<div class="col-md-4">
					<div class="form-group">
						<label for="city">City</label> *				
						<input class="form-control"  placeholder="Enter city" maxlength="20" name="city" id="city" type="text">				
						<?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
						<div class
						="err"></div>
					</div>

					<div class="form-group">
						<label for="contact_person">Contact Person</label> *				
						<input class="form-control" placeholder="Enter contact person" maxlength="50" name="contact_person" id="contact_person" type="text">
							<?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
										<div class="err"></div>
					</div>
				</div>

				<div class="col-md-4">
					<div class="form-group">
						<label for="contact">Contact</label>				
						<textarea class="form-control" placeholder="Enter contact" maxlength="100" rows="4" name="contact" id="contact"></textarea>
								
								<?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		<div class="err"></div>
					</div>
				</div>

				<div class="col-md-4">
					<div class="form-group">
						<label for="gst">GST No</label>				
						<textarea class="form-control" placeholder="Enter gstno" maxlength="50" rows="4" name=" gst" id="gst"></textarea>
								
								<?php $__errorArgs = ['gst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		<div class="err"></div>
					</div>
				</div>

			</div>

			<div class="row">
				<div class="col-md-12 my-5 text-center">
					<input  class="btn cbtn btn-primary" type="submit" name="submit" value="Create">
				</div>
			</div>	
		</form>
		</div> 
	</div>

 
</div>

	

<?php $__env->stopSection(); ?>


<?php $__env->startSection('innerPageJS'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/headoffices/form.blade.php ENDPATH**/ ?>