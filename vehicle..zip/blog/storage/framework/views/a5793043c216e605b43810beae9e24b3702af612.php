    <?php $__currentLoopData = $vehicledata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                                  
                 <td>
                  <div class="d-flex">
                    <a title="View" href="<?php echo e(route('agent-view-permission.show',$vehicle->id)); ?>"> 
                    <i class="fas fa-eye"> </i>
                    </a>
                  </div>
                 </td>
                <?php if($agentviewdata->customer_name): ?>
                 <td tabindex="0"> <a href="#" class="test" ><?php echo e(isset($vehicle->customer_name) ? $vehicle->customer_name:''); ?></a>
                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->agreement_no): ?>
                 <td><?php echo e(isset($vehicle->agreement_no) ? $vehicle->agreement_no:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->prod_n): ?>
                 <td><?php echo e(isset($vehicle->prod_n) ? $vehicle->prod_n:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->region_area): ?>
                 <td><?php echo e(isset($vehicle->region_area) ? $vehicle->region_area:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->office): ?>
                 <td><?php echo e(isset($vehicle->office) ? $vehicle->office:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->branch): ?>
                 <td><?php echo e(isset($vehicle->branch) ? $vehicle->branch:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->cycle): ?>
                 <td><?php echo e(isset($vehicle->cycle) ? $vehicle->cycle:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->paymode): ?>
                 <td><?php echo e(isset($vehicle->paymode) ? $vehicle->paymode:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->emi): ?>
                 <td><?php echo e(isset($vehicle->emi) ? $vehicle->emi:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->tet): ?>
                 <td><?php echo e(isset($vehicle->tet) ? $vehicle->tet:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->noi): ?>
                 <td><?php echo e(isset($vehicle->noi) ? $vehicle->noi:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->allocation_month_grp): ?>
                 <td><?php echo e(isset($vehicle->allocation_month_grp) ? $vehicle->allocation_month_grp:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->tenor_over): ?>
                 <td><?php echo e(isset($vehicle->tenor_over) ? $vehicle->tenor_over:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->charges): ?>
                 <td><?php echo e(isset($vehicle->charges) ? $vehicle->charges:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->gv): ?>
                 <td><?php echo e(isset($vehicle->gv) ? $vehicle->gv:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->model): ?>
                 <td><?php echo e(isset($vehicle->model) ? $vehicle->model:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->regd_num): ?>
                 <td><?php echo e(isset($vehicle->regd_num) ? $vehicle->regd_num:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->chasis_num): ?>
                 <td><?php echo e(isset($vehicle->chasis_num) ? $vehicle->chasis_num:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->engine_num): ?>
                 <td><?php echo e(isset($vehicle->engine_num) ? $vehicle->engine_num:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->make): ?>
                 <td><?php echo e(isset($vehicle->make) ? $vehicle->make:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->rrm_name_no): ?>
                 <td><?php echo e(isset($vehicle->rrm_name_no) ? $vehicle->rrm_name_no:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->rrm_mail_id): ?>
                 <td><?php echo e(isset($vehicle->rrm_mail_id) ? $vehicle->rrm_mail_id:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->coordinator_mail_id): ?>
                 <td><?php echo e(isset($vehicle->coordinator_mail_id) ? $vehicle->coordinator_mail_id:''); ?>

                 </td>
                 <?php endif; ?>
                <?php if($agentviewdata->letter_refernce): ?>
                 <td><?php echo e(isset($vehicle->letter_refernce) ? $vehicle->letter_refernce:''); ?>

                 </td>
                 <?php endif; ?>
                 <?php if($agentviewdata->dispatch_date): ?>
                 <td><?php echo e(isset($vehicle->dispatch_date) ? $vehicle->dispatch_date:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->letter_date): ?>
                 <td><?php echo e(isset($vehicle->letter_date) ? $vehicle->letter_date:''); ?>

                 </td>
                <?php endif; ?>
                <?php if($agentviewdata->valid_date): ?>
                  <td><?php echo e(isset($vehicle->valid_date) ? $vehicle->valid_date:''); ?>

                 </td>
                <?php endif; ?>
              </tr>   
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/agent-permission/dynamic_vehicle_table.blade.php ENDPATH**/ ?>