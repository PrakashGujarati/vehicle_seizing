
<?php $__env->startSection('title', __('Vehicle Add')); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
.input-group-text
{
	background: transparent!important;
	border: transparent!important;
	width: 170px!important;
	font-family: "Roboto",sans-serif!important;
}
.textbox
{
	border-top: transparent!important;
	border-right: transparent!important;
	border-left: transparent!important;
	border-bottom: 1px solid #4285f4!important;
	max-width: 200px!important;
	
}
input[type="text"]:focus {
	box-shadow: 0 1px 0 0 #4285f4!important;
}
.card
{
	border-left: 3.5px solid #ffc107!important;
}
.card-header
{
	background: white!important;
}
.card-footer
{
	background: white!important;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<form method="post" action="<?php echo e(route('Vehicle.update',$VehicleEdit->id)); ?>" >
		<?php echo csrf_field(); ?>
	<?php echo method_field('PUT'); ?>
	<input type="hidden" name="hidden_id" value="<?php echo e($VehicleEdit->id); ?>" >
  <div class="card">
    <div class="card-header">Edit Vehicle</div>
    <div class="card-body">
    	<div class="row">
    		<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Agreement No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->agreement_no); ?>"   name="agreement_no" >
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Vehicle Maker</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->make); ?>"  name="make">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Engine No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->engine_num); ?>"  name="engine_num">
			</div>
    		<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Prod No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->prod_n); ?>"  name="prod_n">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Region Area</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->region_area); ?>"  name="region_area">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Office</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->Office); ?>"  name="Office">
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Branch</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->branch); ?>"  name="branch">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Customer Name</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->customer_name); ?>"  name="customer_name">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Cycle</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->cycle); ?>"  name="cycle">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Paymode</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->paymode); ?>"  name="paymode">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Emi</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->emi); ?>"  name="emi">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Tet</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->tet); ?>"  name="tet">
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Noi</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->noi); ?>"  name="noi">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Allocation Month Grp</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->allocation_month_grp); ?>"  name="allocation_month_grp">
			</div>
		</div>
		
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Charges</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->charges); ?>"  name="charges">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Gv</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->gv); ?>"  name="gv">
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Model</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->model); ?>"  name="model">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Regd No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->regd_num); ?>"  name="regd_num">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Chasis Num</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->chasis_num); ?>"  name="chasis_num">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Rrm Name No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->rrm_name_no); ?>"  name="rrm_name_no">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Rrm Mail Id</span>
				</div>
				<input type="email" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->rrm_mail_id); ?>"  name="rrm_mail_id">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Coordinator Mail Id</span>
				</div>
				<input type="email" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->coordinator_mail_id); ?>"  name="coordinator_mail_id">
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Letter Refernce</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->letter_refernce); ?>"  name="letter_refernce">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Tenor Over</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->tenor_over); ?>"  name="tenor_over">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Dispatch Date</span>
				</div>
				<input type="date" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->dispatch_date); ?>"  name="dispatch_date">
			</div>
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Letter Date</span>
				</div>
				<input type="date" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->letter_date); ?>"  name="letter_date">
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Valid Date</span>
				</div>
				<input type="date" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($VehicleEdit->valid_date); ?>"  name="valid_date">
			</div>
		</div>
		<div class="card-footer">
    		<button type="submit" class="btn btn-primary">Submit</button>
		<a href="<?php echo e(route('Vehicle.index')); ?>" class="btn btn-danger">cancel</a>
    </div>
    </div> 
     
  </div>

 
</form>
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('innerPageJS'); ?>

   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/vehicle/edit.blade.php ENDPATH**/ ?>