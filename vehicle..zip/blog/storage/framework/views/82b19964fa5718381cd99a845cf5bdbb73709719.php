
<?php $__env->startSection('title', __('Office Add')); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="card">
		<div class="card-header">Office Add</div>
		<div class="card-body">
			<form method="post" id="Officeform" action="<?php echo e(route('office.store')); ?>">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<label for="name">Name</label>*				
							<input placeholder="Enter  office name" maxlength="100" class="form-control" name="name" id="name" type="text">				
							<div class="err"></div>
							<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						<div class="form-group">
							<label for="contact_person">Contact Person</label> *				
							<input class="form-control" placeholder="Enter contact person"  name="contact_person" id="contact_person" type="text" onkeypress="return isNumberKey(event)">
							<?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>			
								<div class="err"></div>
						</div>

					</div>

					<div class="col-md-4">
						<div class="form-group">
							<label for="contact">Contact</label>				
							<textarea class="form-control" placeholder="Enter contact"  rows="4" name="contact" id="contact" onkeypress="return isNumberKey(event)"></textarea>	
							<?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>			
							<div class="err"></div>
						</div>
					</div>

					<div class="col-md-4">
						<div class="form-group">
							<label for="address">Address</label>				
							<textarea class="form-control" placeholder="Enter address" maxlength="
							200" rows="4" name="address1" id="address1"></textarea>				
							<?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							<div class="err"></div>

						</div>
					</div>

					<div class="col-md-4">
						<div class="form-group">
							<label for="city">City</label> *				
							<input class="form-control"  placeholder="Enter city" maxlength="20" name="city" id="city" type="text">	
							<?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>			
							<div class="err"></div>
						</div>

						<div class="form-group">
							<label for="contact_person">head Office Name</label> *	
							<select class="form-control" name="head_office_id" id="head_office_id" >
								<option value="" disabled="" selected="">Select head Office</option>
								<?php $__currentLoopData = $headOfficesname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hOfficesname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($hOfficesname->id); ?>"><?php echo e($hOfficesname->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>			
							<?php $__errorArgs = ['head_office_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							<div class="err"></div>
						</div>
					</div>

					<div class="col-md-4">
						<div class="form-group">
							<label for="contact">Branch Code</label>	
							<input placeholder="Enter Branch Code" maxlength="100" class="form-control" name="branch_code" id="branch_code" type="text">
							<?php $__errorArgs = ['branch_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							<div class="err"></div>	
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="contact">Branch</label>	
							<input placeholder="Enter Branch" class="form-control" name="branch" id="branch" type="text">
							<?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="validation-msg">
								<?php echo e($message); ?>

							</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							<div class="err"></div>	
						</div>
					</div>


				</div>

				<div class="row">
					<div class="col-md-12 my-5 text-center">
						<input  class="btn cbtn btn-primary" type="submit" name="submit" value="Create">
						<a href="<?php echo e(route('office.index')); ?>" class="btn btn-danger">cancel</a>
					</div>
				</div>	
			</form>
		</div> 
	</div>


</div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('onPageJs'); ?>


<script type="text/javascript">
	$(function() {
		$("#Officeform").validate({
			rules: {
				name: {
					required: true
				},
				contact_person: {
					  required: true,
					  minlength: 10,
		     		  maxlength: 10
				},
				contact: {
					minlength: 10,
		     		maxlength: 10,
					required: true
				},
				address1:{
					required: true
				},
				city:{
					required: true	
				},
				
				branch_code:{
					required: true	
				},
				branch :{
					required: true	
				},
				head_office_id:{
					required: true	
				}

			},
			messages: {
				name: {
					required: "Name is a required field"
				},
				contact_person: {
					required: "Person Contact is a required field"
					
				},
				contact: {
					required: "Contact is a required field"
				},
				address1: {
					required: "Address is a required field"
				},
				city:{
					required: "City is a required field"
				},
				branch_code: {
					required: "Branch Code is a required field"
				},
				branch:{
					required: "Branch is a required field"
				}
				head_office_id:{
					required: "Head Office Name is a required field"
				}
			}
		});
	});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/office/form.blade.php ENDPATH**/ ?>