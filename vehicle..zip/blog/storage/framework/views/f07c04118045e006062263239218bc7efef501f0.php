
<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
  .header-roles
  {
    background: #1976d2;
    padding: 0 20px;
    height: 30px;
    line-height: 30px;
    clear: left;
    position: absolute;
    top: 12px;
    left: -2px;
    color: #ffffff;
  }
  body {
    font-family: "Poppins", sans-serif;
    color: #67757c;
    font-weight: 300;
  }

  .ribbon-primary {
    background: #5c4ac7;
  }
  .ribbon {
    padding: 0 20px;
    height: 30px;
    line-height: 30px;
    clear: left;
    position: absolute;
    top: 12px;
    left: -2px;
    color: #ffffff;
}
.ribbon-right {
    left: auto;
    right: -2px;
}


  </style>
  <?php $__env->stopSection(); ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-header"><<span class="header-roles"> Roles</span></div>
          <div class="card-body">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Sr</th>
                  <th>Name</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php if(isset($roles)): ?>
                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td> <?php echo e($loop->iteration); ?></td>
                  <td>
                    <span style="cursor: pointer">
                      <a href="<?php echo e(route('role.get', ['role_id' => $role->id ])); ?>">
                        <?php echo e($role->slug ?? $role->name); ?>

                      </a>
                    </span>
                  </td>
                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No Roles</p>
                <?php endif; ?>
                <?php endif; ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <?php if(request('role_id') && $selected_role ): ?>
            <div class="ribbon ribbon-primary"> <?php echo e($selected_role->slug ?? $selected_role->name); ?> has Permissions</div>
            <div class="text-right ribbon ribbon-primary ribbon-right"  
            style="cursor:pointer;"
            onclick="event.preventDefault(); document.getElementById('assign_permission_form').submit();">
            Save
          </div>
          <br><br>
          <div class="ribbon-content">
            <form action="<?php echo e(route('role.assign_permission', [ 'role_id' => request('role_id') ])); ?>" method="post" id="assign_permission_form">
              <?php echo csrf_field(); ?>
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      
                      <th>View</th>
                      <th>Create</th>
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
       
                    <td>
                      <input type="checkbox" class="chk-col-blue"
                      id="permission_checkbox_<?php echo e($permission->id); ?>"
                      name="permissions[<?php echo e($permission->name); ?>]"
                      <?php echo e(in_array($permission->name , $selected_role->getAllPermissions()->pluck('name')->toArray()) ? "checked":""); ?>

                      >
                      <label for="permission_checkbox_<?php echo e($permission->id); ?>">
                        <?php echo e($permission->slug); ?>

                      </label>
                    </td>
                    <?php if( $loop->iteration % 4 == 0 ): ?>
                    <tr> <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <p> Role does not have any permissions yet </p>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>

                 
              </form>
            </div>
            <?php else: ?>
            <div class="ribbon ribbon-primary"> Permissions</div>
            <hr>
            <p>Please select any appropriate Role</p>
            <?php endif; ?>
          </div>
        </div>
      </div>

    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php $__env->startSection('onPageJs'); ?>

  
<script type="text/javascript">

  $( document ).ready(function() {
    $(".alert" ).fadeOut(3000);
});

  </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/spatie-role/table.blade.php ENDPATH**/ ?>