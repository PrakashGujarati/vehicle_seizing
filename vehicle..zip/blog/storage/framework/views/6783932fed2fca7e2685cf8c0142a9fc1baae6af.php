    <?php $__currentLoopData = $vehicledata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><input type="checkbox"  name="vehicle_id" value="<?php echo e($vehicle->id); ?>"></td>
                
                 <td>
                  <div class="d-flex">
                    <a title="View" href="<?php echo e(route('Vehicle.show',$vehicle->id)); ?>"> 
                    <i class="fas fa-eye"> </i>
                    </a> &nbsp;
                    <a title="Edit" href="<?php echo e(route('Vehicle.edit',$vehicle->id)); ?>"> 
                      <i class="fas fa-edit"></i>
                    </a>
                    <form action="<?php echo e(URL::route('Vehicle.destroy',$vehicle->id)); ?>" method="POST">
                      <input type="hidden" name="_method" value="DELETE">
                      <?php echo csrf_field(); ?>
                      <button style="background-color: Transparent;
                      background-repeat:no-repeat;
                      border: none;
                      cursor:pointer;
                      overflow: hidden;
                      outline:none;" class="text-danger mr-2"> <i class="fas fa-trash"></i></button>
                    </form>
                  </div>
                 </td>
                 <td tabindex="0"> <a href="#" class="test" ><?php echo e(isset($vehicle->customer_name) ? $vehicle->customer_name:''); ?></a>
                    
                 </td>
                 <td><?php echo e(isset($vehicle->agreement_no) ? $vehicle->agreement_no:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->prod_n) ? $vehicle->prod_n:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->region_area) ? $vehicle->region_area:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->office) ? $vehicle->office:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->branch) ? $vehicle->branch:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->cycle) ? $vehicle->cycle:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->paymode) ? $vehicle->paymode:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->emi) ? $vehicle->emi:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->tet) ? $vehicle->tet:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->noi) ? $vehicle->noi:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->allocation_month_grp) ? $vehicle->allocation_month_grp:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->tenor_over) ? $vehicle->tenor_over:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->charges) ? $vehicle->charges:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->gv) ? $vehicle->gv:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->model) ? $vehicle->model:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->regd_num) ? $vehicle->regd_num:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->chasis_num) ? $vehicle->chasis_num:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->engine_num) ? $vehicle->engine_num:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->make) ? $vehicle->make:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->rrm_name_no) ? $vehicle->rrm_name_no:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->rrm_mail_id) ? $vehicle->rrm_mail_id:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->coordinator_mail_id) ? $vehicle->coordinator_mail_id:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->letter_refernce) ? $vehicle->letter_refernce:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->dispatch_date) ? $vehicle->dispatch_date:''); ?>

                 </td>
                 <td><?php echo e(isset($vehicle->letter_date) ? $vehicle->letter_date:''); ?>

                 </td>
                  <td><?php echo e(isset($vehicle->valid_date) ? $vehicle->valid_date:''); ?>

                 </td>
              </tr>   
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/vehicle/dynamic_vehicle_table.blade.php ENDPATH**/ ?>