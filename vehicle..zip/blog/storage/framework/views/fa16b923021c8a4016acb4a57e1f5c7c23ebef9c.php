
<?php $__env->startSection('title', __('Vehicle Details')); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
.input-group-text
{
	background: transparent!important;
	border: transparent!important;
	width: 170px!important;
	font-family: "Roboto",sans-serif!important;
}
.textbox
{
	border-top: transparent!important;
	border-right: transparent!important;
	border-left: transparent!important;
	border-bottom: 1px solid #4285f4!important;
	max-width: 200px!important;
	background-color: white!important;
}
input[type="text"]:focus {
	box-shadow: 0 1px 0 0 #4285f4!important;
}
.card
{
	border-left: 3.5px solid #ffc107!important;
}
.card-header
{
	background: white!important;
}
.card-footer
{
	background: white!important;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<form method="post" >
  <div class="card">
    <div class="card-header">Identify Five Vehicles</div>
    <div class="card-body">
    	<div class="row">
    		<div class="input-group col-md-6">
                <?php if($agentviewdata->agreement_no): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Agreement No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->agreement_no); ?>" disabled=""  name="agreement_no" >
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->make): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Vehicle Maker</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->make); ?>" disabled="" name="make">
                <?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->engine_num): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Engine No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->engine_num); ?>" disabled="" name="engine_num">
                <?php endif; ?>

			</div>
    		<div class="input-group col-md-6">
                <?php if($agentviewdata->prod_n): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Prod No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->prod_n); ?>" disabled="" name="prod_n">
                <?php endif; ?>

			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->region_area): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Region Area</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->region_area); ?>" disabled="" name="region_area">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->office): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Office</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->Office); ?>" disabled="" name="Office">
			<?php endif; ?>
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
                <?php if($agentviewdata->branch): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Branch</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->branch); ?>" disabled="" name="branch">
				<?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->customer_name): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Customer Name</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->customer_name); ?>" disabled="" name="customer_name">
				<?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->cycle): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Cycle</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->cycle); ?>" disabled="" name="cycle">
				<?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->paymode): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Paymode</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->paymode); ?>" disabled="" name="paymode">
                <?php endif; ?>

			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->emi): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Emi</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->emi); ?>" disabled="" name="emi">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->tet): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Tet</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->tet); ?>" disabled="" name="tet">
                <?php endif; ?>
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
                <?php if($agentviewdata->noi): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Noi</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->noi); ?>" disabled="" name="noi">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->allocation_month_grp): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Allocation Month Grp</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->allocation_month_grp); ?>" disabled="" name="allocation_month_grp">
                <?php endif; ?>
			</div>
		</div>
		
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->charges): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Charges</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->charges); ?>" disabled="" name="charges">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->gv): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Gv</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->gv); ?>" disabled="" name="gv">
                <?php endif; ?>
			</div>
		</div>
		<div class="row">
    		<div class="input-group col-md-6">
                <?php if($agentviewdata->model): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Model</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->model); ?>" disabled="" name="model">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->regd_num): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Regd No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->regd_num); ?>" disabled="" name="regd_num">
                <?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->chasis_num): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Chasis Num</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->chasis_num); ?>" disabled="" name="chasis_num">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->rrm_name_no): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Rrm Name No</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->rrm_name_no); ?>" disabled="" name="rrm_name_no">
                <?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->rrm_mail_id): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Rrm Mail Id</span>
				</div>
				<input type="email" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->rrm_mail_id); ?>" disabled="" name="rrm_mail_id">
                <?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->coordinator_mail_id): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Coordinator Mail Id</span>
				</div>
				<input type="email" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->coordinator_mail_id); ?>" disabled="" name="coordinator_mail_id">
                <?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->tenor_over): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Tenor Over</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->tenor_over); ?>" disabled="" name="tenor">
                <?php endif; ?>
			</div>

    		<div class="input-group col-md-6">
                <?php if($agentviewdata->letter_refernce): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Letter Refernce</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->letter_refernce); ?>" disabled="" name="letter_refernce">
				<?php endif; ?>
			</div>
			
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->dispatch_date): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Dispatch Date</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->dispatch_date); ?>" disabled="" name="dispatch_date">
				<?php endif; ?>
			</div>
			<div class="input-group col-md-6">
                <?php if($agentviewdata->letter_date): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Letter Date</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->letter_date); ?>" disabled="" name="letter_date">
				<?php endif; ?>
			</div>
		</div>
		<div class="row">
			<div class="input-group col-md-6">
                <?php if($agentviewdata->valid_date): ?>
				<div class="text-border">
					<span class="input-group-text" id="inputGroup-sizing-default">Valid Date</span>
				</div>
				<input type="text" class="form-control textbox" aria-label="Default" aria-describedby="inputGroup-sizing-default" value="<?php echo e($vehicledata->valid_date); ?>" disabled="" name="valid_date">
				<?php endif; ?>
			</div>
		</div>
    </div> 
     
  </div>

 
</form>
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('innerPageJS'); ?>

   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/agent-permission/display.blade.php ENDPATH**/ ?>