
<nav id="sidebar" class="sidebar">
    <div class="sidebar-sticky">
 
    <ul class="list-unstyled components" style="font-size: 14px;">

        
        




         <li  class="">
            <a href="#"><i class="fas fa-tachometer-alt" aria-hidden="true"></i>Dashboard</a>
        </li>


        <?php if( Auth::user()->name == "Admin"): ?>
        <li  class="#">
            <a href="<?php echo e(route('Vehicle.index')); ?>"><i class="fas fa-user menu-icon"></i>Vehicles</a>
        </li>
        <li  class="#">
            <a href="<?php echo e(route('headoffice.index')); ?>"><i class="fas fa-user menu-icon"></i>Head Office</a>
        </li>
        <li  class="#">
            <a href="<?php echo e(route('office.index')); ?>"><i class="fas fa-user menu-icon"></i>Office</a>
        </li>
        <li  class="#">
            <a href="<?php echo e(route('role.get')); ?>"><i class="fas fa-user menu-icon"></i>Roles</a>
        </li>
        <li  class="#">
            <a href="<?php echo e(route('user.index')); ?>"><i class="fas fa-user menu-icon"></i>User</a>
        </li>
       <li  class="#">
            <a href="<?php echo e(route('agent-view-permission.index')); ?>"><i class="fas fa-user menu-icon"></i>View Fields</a>
        </li>
        <li  class="#">
            <a href="<?php echo e(route('subscription.index')); ?>"><i class="fas fa-user menu-icon"></i>Subscriptions</a>
        </li>
       <?php endif; ?>

        <?php if( Auth::user()->role == "agent"): ?>

        <li  class="#">
            <a href="<?php echo e(route('agentview.index')); ?>"><i class="fas fa-user menu-icon"></i>
             Identify Five Vehicles</a>
        </li>
       <?php endif; ?>


    </ul>
    <ul class="list-unstyled CTAs">
        <li><a href="#" class="article"></a></li>
    </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/layouts/menu.blade.php ENDPATH**/ ?>