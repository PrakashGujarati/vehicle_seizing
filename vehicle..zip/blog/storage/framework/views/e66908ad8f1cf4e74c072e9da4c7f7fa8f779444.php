
<?php $__env->startSection('title', __('Dashboard')); ?>
<?php $__env->startSection('content'); ?>

  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('onPageJs'); ?>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a\final_project\blog\resources\views/dashboard_stat.blade.php ENDPATH**/ ?>