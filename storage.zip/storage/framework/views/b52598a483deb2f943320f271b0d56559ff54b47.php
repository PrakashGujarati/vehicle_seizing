<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">   
    <link rel="stylesheet" href="<?php echo e(url(mix('css/vendor.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(url(mix('css/app.css'))); ?>">    
    
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminCustom.css')); ?>">    
    <style>
.four-boot .dropdown .btn{
    
    overflow: hidden !important;
    white-space: nowrap !important;
    display: block !important;
    text-overflow: ellipsis !important;
}
.toolbar {
    float:left;
}
 .list-group-item  .remove_tmp_attachment{
          float: right !important;
          text-align: right;

        }

        iframe  .panel-heading .panel-title{
          display: none !important;
        }

  
  /* relevant styles */
.img__wrap {
  position: relative;
 
}

.img__description_layer {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(36, 62, 206, 0.6);
  color: #fff;
  visibility: hidden;
  opacity: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 30px;

  /* transition effect. not necessary */
  transition: opacity .2s, visibility .2s;
}

.img__wrap:hover .img__description_layer {
  visibility: visible;
  opacity: 1;
}

.img__description {
  transition: .2s;
  transform: translateY(1em);
}

.img__wrap:hover .img__description {
  transform: translateY(0);
}

.daterangepicker{
    z-index: 1100 !important;
}
.btn{
  border-radius: 2px;

}
.container
{
  max-width: 1045px;
}
</style>
<?php echo $__env->yieldContent('css'); ?>



</head>
<body>

<nav class="navbar navbar-expand navbar-dark bg-dark flex-md-nowrap">
   <a class="navbar-brand navbar-brand col-sm-3 col-md-2 mr-0 d-none d-sm-block" href="#">
      <div>
       
         
         Admin
         
      </div>
   </a>
   <div class="collapse navbar-collapse" id="navbarsExample02">
      <ul class="navbar-nav">
         <li class="nav-item active">
            <a href="#" id="sidebarCollapse"><i class="fa fa-bars"></i></a>
         </li>
      </ul>
      <ul class="navbar-nav ml-auto">
         
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">  <?php echo e(Auth::user()->name); ?></a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown01" style="min-width: 300px; font-size: 14px;">
               
               <h6 class="dropdown-header text-center"><?php echo e(Auth::user()->name); ?></h6>
               
               <hr>
               
               <a class="dropdown-item" href="">My Account</a>
               <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> Logout</a>
               <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                  
               </form>
            </div>
         </li>
      </ul>
   </div>
</nav>
    
<div class="wrapper">
   <!-- Sidebar Holder -->
   <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Page Content Holder -->
   <div id="content">
    <br>
      <div class="container">
         <div class="row">
            <div class="col-md-12">               
               <?php echo $__env->make('layouts.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               <?php echo $__env->yieldContent('content'); ?>
            </div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">

    

</script>
  
<script type="text/javascript" src="<?php echo e(url(mix('js/app.js'))); ?>"></script>
<script  type="text/javascript" src="<?php echo e(url(mix('js/vendor.js'))); ?>"></script>
<script  type="text/javascript" src="<?php echo e(url(mix('js/main.js'))); ?>"></script>
<script  type="text/javascript" src="<?php echo e(asset('vendor/gantt-chart/js/modified_jquery.fn.gantt.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.min.js')); ?>" ></script>

<script type="text/javascript">  


function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
 



  accounting.settings = <?php echo json_encode(config('constants.money_format')) ?>;

    $(function(){

         <?php if($flash = session('message')) {?>
            $.jGrowl("<?php echo $flash; ?>", { position: 'bottom-right'});
        <?php } ?>

        $('.currency_changed').change(function(){
            $(this)
        });
    });
  


$(document).on('click','.change_task_status',function(e){

        e.preventDefault();

        var url       = $(this).attr("href");
        var name      = $(this).data('name');
        var id        = $(this).data('id');
        var task_id   = $(this).data('task');


        if(url)
        {
          $scope = this;
          $.post(url , { "_token": global_config.csrf_token, task_id : task_id, status_id : id }).done(function( response ) {
                      
              if(response.status == 1)
              {
                $($scope).closest(".dropdown").find(".btn").text(name);
              }
              
          });

        }       

    });

$(document).ready(function() {
  $(document).on('focus', ':input', function() {
    $(this).attr('autocomplete', 'off');
  });
});

</script>


 
    <script src="https://js.pusher.com/4.3/pusher.min.js"></script> 

<script  src="<?php echo e(url(mix('js/tinymce.js'))); ?>"></script>

<?php echo $__env->yieldContent('onPageJs'); ?>
 

</body>

</html>
<?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/layouts/main.blade.php ENDPATH**/ ?>