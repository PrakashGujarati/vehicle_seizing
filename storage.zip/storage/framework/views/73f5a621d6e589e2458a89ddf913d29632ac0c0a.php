   <?php $__currentLoopData = $headofficesdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $headoffice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
           <td><?php echo e(isset($headoffice->name) ? $headoffice->name:''); ?></td>
           <td><?php echo e(isset($headoffice->vendor_code) ? $headoffice->vendor_code:''); ?></td>
           <td><?php echo e(isset($headoffice->city) ? $headoffice->city:''); ?></td>
           <td><?php echo e(isset($headoffice->contact_person) ? $headoffice->contact_person:''); ?></td>
           <td><?php echo e(isset($headoffice->address1) ? $headoffice->address1:''); ?></td>
           <td><?php echo e(isset($headoffice->address2) ? $headoffice->address2:''); ?></td>
           <td><?php echo e(isset($headoffice->contact) ? $headoffice->contact:''); ?></td>
           <td><?php echo e(isset($headoffice->gst) ? $headoffice->gst:''); ?></td>
           <td>
            <div class="d-flex">
            <a title="Edit" href="<?php echo e(route('headoffice.edit',$headoffice->id)); ?>">
                <i class="fas fa-edit"></i>
              </a>
              <form action="<?php echo e(URL::route('headoffice.destroy',$headoffice->id)); ?>" method="POST">
                  <input type="hidden" name="_method" value="DELETE">
                  <?php echo csrf_field(); ?>
                  <button style="background-color: Transparent;
                  background-repeat:no-repeat;
                  border: none;
                  cursor:pointer;
                  overflow: hidden;
                  outline:none;" class="text-danger mr-2"> <i class="fas fa-trash"></i></button>
              </form>
              </div>
           </td>

         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/headoffices/dynamic_headoffice_table.blade.php ENDPATH**/ ?>