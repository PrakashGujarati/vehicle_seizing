<?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e(isset($subscription->Username->name) ? $subscription->Username->name:''); ?></td>
  <td><?php echo e(isset($subscription->days) ? $subscription->days:''); ?></td>
  <td><?php echo e(isset($subscription->amount) ? $subscription->amount:''); ?></td>
  <td><?php echo e(isset($subscription->payment_status) ? $subscription->payment_status:''); ?></td>
  <td><?php echo e(isset($subscription->payment_mode) ? $subscription->payment_mode:''); ?></td>
  <td><?php echo e(isset($subscription->notes) ? $subscription->notes:''); ?></td>
  

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/subscription/dynamic_subscription_table.blade.php ENDPATH**/ ?>