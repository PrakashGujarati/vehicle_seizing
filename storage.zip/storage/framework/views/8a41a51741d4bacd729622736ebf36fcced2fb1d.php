
<?php $__env->startSection('title', __('Dashboard')); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css" media="screen">
.icon
{
	 font-size: 50px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="">
		<div class="col-md-12">
		<div class="row">
	        <?php if( Auth::user()->name == "Admin"): ?>
			<div class="col-md-4">
				<div class="card">
				  <div class="card-body">
				  	<center>
				  		<a href="<?php echo e(route('user.index')); ?>" >
				  			<i style="color:#0CC27E" class="fas fa-users icon"></i><br>
				    		<b style="color:#0CC27E">Active Agents (<?php echo e(isset($UserActiveCount) ? $UserActiveCount:'0'); ?>)</b>
				    	</a>
				    </center>
				  </div>
				</div>
			</div>

			<div class="col-md-4">
				<div class="card">
					<div class="card-body">
						<center>
							<a href="#" >
				  				<i style="color:#FF586B;" class="fas fa-user-times icon"></i><br>
								<b style="color:#FF586B;">Inactive Agents(<?php echo e(isset($UserInactiveCount) ? $UserInactiveCount:'0'); ?>)</b>
							</a>
						</center>
					</div>
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="card">
				  <div class="card-body">
				  	<center>
				  		<a href="<?php echo e(route('Vehicle.index')); ?>" >
				  			<i class="fa fa-car icon"></i><br>
				    		<b>Total Vehicles (<?php echo e(isset($VehicleCount) ? $VehicleCount:'0'); ?>)</b>
				   		 </a>
				    </center>
				  </div>
				</div>
			</div>

			<?php endif; ?>
	        <?php if( Auth::user()->role == "agent"): ?>
	        	<div class="col-md-4">
				<div class="card">
				  <div class="card-body">
				  	<center>
				  		<a href="<?php echo e(route('agentview.index')); ?>" >
				  			<i class="fa fa-car icon"></i><br>
				    		<b>Total Vehicles (<?php echo e(isset($VehicleCount) ? $VehicleCount:'0'); ?>)</b>
				   		 </a>
				    </center>
				  </div>
				</div>
			</div>
			<?php endif; ?>
		</div>
		<div class="row mt-3">
	        <?php if( Auth::user()->name == "Admin"): ?>
	        <div class="col-md-4">
	        	<div class="card">
	        		<div class="card-body">
	        			<center>
	        				<a href="<?php echo e(route('headoffice.index')); ?>" >
	        					<i class="fa fa-building icon"></i><br>
	        					<b>Total Head Office (<?php echo e(isset($HeadOfficeCount) ? $HeadOfficeCount:'0'); ?>)</b>
	        				</a>
	        			</center>
	        		</div>
	        	</div>
	        </div>
			<?php endif; ?>
		</div>

		
	</div>
</div>


  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('onPageJs'); ?>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/dashboard_stat.blade.php ENDPATH**/ ?>