<?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e(isset($user->name) ? $user->name:''); ?></td>
  <td><?php echo e(isset($user->email) ? $user->email:''); ?></td>
  <td><?php echo e(isset($user->contact) ? $user->contact:''); ?></td>
  <td><?php echo e(isset($user->role) ? $user->role:''); ?></td>


  <td>
    <?php if($user->status=="Active"): ?>
        <span style="background:#0CC27E;color: white;padding: 2px;border-radius: 5px;padding: 5px">Active</span>
        <?php else: ?>
        <span style="background:#FF586B;padding: 2px;color: white;border-radius: 5px;padding: 5px">Inactive</span>
    <?php endif; ?>

  <td>

      <a title="Edit" href="<?php echo e(route('user.edit',$user->id)); ?>">
        <i class="fas fa-edit"></i>
      </a>

    
  </td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/user/dynamic_user_table.blade.php ENDPATH**/ ?>