
<?php $__env->startSection('title', __('Vehicle List')); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
<div class="alert alert-success successmessage"></div>
<div class="alert alert-danger dangermessage"></div>

   <div class="row">
      <div class="col-md-6">
         <h5>Vehicle List</h5>
      </div>

   </div>
    <hr>

   <div class="row d-flex">
      <div class="col-md-4">
        <input type="text" class="searchString form-control" name="s" id="search"  placeholder="Search..." id="myInput"  autocompelete="false">
      </div>
      <div class="col-md-3">
      </div>
      <div class="col-md-4 text-right d-flex">
        
      </div>
    </div><br>
    
    <div class="table-responsive">
     <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="data">
        <thead>
           <tr> 
                <th>Action</th>

                <?php if($agentviewdata->customer_name): ?>
                   <th>Customer Name</th>
                <?php endif; ?>
                <?php if($agentviewdata->agreement_no): ?>
                  <th>Agreement No</th>
                <?php endif; ?>
                <?php if($agentviewdata->prod_n): ?>
                  <th>Prod N</th>
                <?php endif; ?>

                <?php if($agentviewdata->region_area): ?>
                   <th>Region Area</th>
                <?php endif; ?>
                <?php if($agentviewdata->office): ?>
                    <th>Office</th>
                <?php endif; ?>
                <?php if($agentviewdata->branch): ?>
                  <th>Branch</th>
                <?php endif; ?>
                <?php if($agentviewdata->cycle): ?>
                    <th>Cycle</th>
                <?php endif; ?>
                <?php if($agentviewdata->paymode): ?>
                   <th>Paymode</th>
                <?php endif; ?>
                <?php if($agentviewdata->emi): ?>
                 <th>Emi</th>
                <?php endif; ?>
                <?php if($agentviewdata->tet): ?>
                  <th>Tet</th>
                <?php endif; ?>
                <?php if($agentviewdata->noi): ?>
                   <th>Noi</th>
                <?php endif; ?>
                <?php if($agentviewdata->allocation_month_grp): ?>
                   <th>Allocation Month Grp</th>
                <?php endif; ?>
                <?php if($agentviewdata->tenor_over): ?>
                   <th>Tenor Over</th>
                <?php endif; ?>
                <?php if($agentviewdata->charges): ?>
                  <th>Charges</th>
                <?php endif; ?>
                <?php if($agentviewdata->gv): ?>
                  <th>Gv</th>
                <?php endif; ?>
                <?php if($agentviewdata->model): ?>
                  <th>Model</th>
                <?php endif; ?>
                <?php if($agentviewdata->regd_num): ?>
                   <th>Regd Num</th>
                <?php endif; ?>
                <?php if($agentviewdata->chasis_num): ?>
                  <th>Chasis Num</th>
                <?php endif; ?>
                <?php if($agentviewdata->engine_num): ?>
                  <th>Engine Num</th>
                <?php endif; ?>
                <?php if($agentviewdata->make): ?>
                   <th>Make</th>
                <?php endif; ?>
                <?php if($agentviewdata->rrm_name_no): ?>
                   <th>Rrm Name No</th>
                <?php endif; ?>
                <?php if($agentviewdata->rrm_mail_id): ?>
                  <th>Rrm Mail Id</th>
                <?php endif; ?>
                <?php if($agentviewdata->coordinator_mail_id): ?>
                   <th>Letter Refernce</th>
                <?php endif; ?>
                <?php if($agentviewdata->letter_refernce): ?>
                  <th>Dispatch Date</th>
                <?php endif; ?>
                <?php if($agentviewdata->dispatch_date): ?>
                    <th>Dispatch Date</th>
                <?php endif; ?>
                <?php if($agentviewdata->letter_date): ?>
                    <th>Letter Date</th>
                <?php endif; ?>
                <?php if($agentviewdata->valid_date): ?>
                  <th>Valid Date</th>
                <?php endif; ?>
           </tr>
        </thead>
        <tbody class="vehicle_table_dynamic">
             <?php echo $__env->make('agent-permission.dynamic_vehicle_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tbody>
     </table>
   </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('onPageJs'); ?>
 
<script type="text/javascript">

$(document).ready(function() {
        /*$('#myTable').DataTable();*/
        $('.successmessage').css('display','none');
        $('.dangermessage').css('display','none');
    });
$('#search').on('keyup',function(){
    var myInput=$(this).val();
    $.ajax({
      type : 'get',
      url : '<?php echo e(route('AgentVehicle.search')); ?>',
      data: {
              "s":myInput,
            },
      success:function(data){
         $('.vehicle_table_dynamic').html(data.data);
              tableScript();
      }
    });
  })




</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/agent-permission/table.blade.php ENDPATH**/ ?>