
<?php $__env->startSection('title', __('Subscription Add')); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="card">
		<div class="card-header">Subscription Add</div>
		<div class="card-body">
			<form method="post" action="<?php echo e(route('subscribers.store')); ?>">
    		<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-4">
					<div class="field-group">
						<label for="User_status">User Name</label> *<br>				
						<select class="form-control" name="user_id" id="user_id">
							<option value="" disabled="" selected="">Select User Name</option>
							<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>				
						<?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>

				<div class="col-md-4">
					<div class="field-group">
						<label for="email">Days</label> *<br>				
						<input class="form-control" placeholder="Enter Days"  class="strlo" name="days" id="days" type="text">	
						<?php $__errorArgs = ['days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>

			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="field-group">
						<label for="User_status">Payment</label> *<br>				
						<select class="form-control" name="payment_status" id="payment_status">
							<option value="" disabled="" selected="">Select Payment Status</option>
							<option value="due">Due</option>
							<option value="paid">Paid</option>
						</select>				
						<?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="col-md-4">
					<div class="field-group">
						<label for="User_status">Payment Mode</label> *<br>				
						<select class="form-control" name="payment_mode" id="payment_mode">
							<option value="" disabled="" selected="">Select Payment Mode</option>
							<option value="debit">Debit</option>
							<option value="cash">Cash</option>
							<option value="credit">Credit</option>
							<option value="online">Online</option>
						</select>				
						<?php $__errorArgs = ['payment_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="col-md-4">
					<div class="field-group">
						<label for="contact">Notes</label><br>				
						<input type="text" class="form-control" name="notes" id="notes" placeholder="Enter Notes" >
						<?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:#dc3545">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12 my-5 text-center">
					<input  class="btn cbtn btn-primary" type="submit" name="submit" value="Create">
				</div>
			</div>	
		</form>
		</div> 
	</div>

 
</div>

	

<?php $__env->stopSection(); ?>


<?php $__env->startSection('onPageJs'); ?>
		
<script type="text/javascript">
	
</script>			

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\live_project\vehicle_seizing\resources\views/subscription/form.blade.php ENDPATH**/ ?>